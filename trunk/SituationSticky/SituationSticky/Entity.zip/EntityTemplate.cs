﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

/****************************************************************************/
/* Class Name  : $safeitemname$                                             */
/* Author      : $username$                                                 */
/* Date Created: $time$                                                     */
/****************************************************************************/

namespace SituationSticky
{
    class $safeitemname$ : Entity
    {
        #region Constants
        // Hardcoded class settings

        #endregion


        #region Members
        // Variable class members

        #endregion


        #region Init and Disposal

        public $safeitemname$(EntityList list, Vector2 position, float width, float height, float direction)
            : base(list, position, width, height, direction)
        { }

        /// <summary>
        /// Initializes the entity with the correct settings.
        /// </summary>
        /// <returns>The string name of the entity.</returns>
        public override string Initialize()
        {
            base.Initialize();

            // Animations
            _Animations = new AnimationSet();
            _Animations.AddAnimation(new Animation(null, "Normal", 1, 1, 1f);

            // Settings
            _DynamicLighting = false;
            _Depth = 0.5f;
            _Temporary = false;

            return "DefaultEntityName";
        }

        #endregion


        #region Update

        /// <summary>
        /// Extends the update functionality for this entity.
        /// </summary>
        /// <param name="time">The XNA gametime parameter.</param>
        public override void Update(GameTime time)
        {
            base.Update(time);
        }

        #endregion


        #region Draw

        /// <summary>
        /// Extends the draw functionality for this entity.
        /// </summary>
        /// <param name="time">The XNA gametime parameter.</param>
        /// <param name="batch">The spritebatch to render on.</param>
        public override void Draw(GameTime time, SpriteBatch batch)
        {
            base.Draw(time, batch);
        }

        #endregion


        #region Utility

        #endregion
    }
}
